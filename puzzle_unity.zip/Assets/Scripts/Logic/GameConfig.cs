﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class GameConfig
{
    public static int Camera_Max_Distance = 100;
    public static int Camera_Min_Distance = 10;
}
