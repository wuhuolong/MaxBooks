﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UILevelMenu : UIWindows
{
    protected override void InitComp()
    {

    }

    protected override void InitData()
    {

    }
}
