﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UISimTips : UITips
{
    protected override void InitComp()
    {

    }
    protected override void InitData()
    {


    }

    public void BtnClickOk()
    {

    }

    public void BtnClickCancel()
    {

    }
}
